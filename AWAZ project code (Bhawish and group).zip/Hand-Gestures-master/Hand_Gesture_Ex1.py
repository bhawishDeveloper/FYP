import cv2
import numpy as np
import tkinter as Tk
from Hand_Gesture_Ex2 import open_dialog2

def open_dialog1():
    # converting my image in grayscale
    hand = cv2.imread('Capture.png',0)
    # thresholding my grayscale image
    ret, the = cv2.threshold(hand, 70, 255, cv2.THRESH_BINARY)

    _,contours,_ = cv2.findContours(the.copy(),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    hull = [cv2.convexHull(c) for c in contours]
    final = cv2.drawContours(hand, hull, -1, (255,0,0))

    cv2.imshow('Originals', hand)
    cv2.imshow('Thresh',the)
    cv2.imshow('Convex hull',final)

    cv2.waitKey(0)
    cv2.destroyAllWindows()
    open_dialog2()

if __name__ == "__main__":
    open_dialog1()