# Hand-Gestures
Hand Gestures using Open-Cv Python

Put them in same folder. 

1st run Hand_Gesture_Ex1.py. It will train your machine, with the help of Capture.png 

2nd run Hand_Gesture_Ex2.py, it give the final output.
Put your hand in the green box.
