
from tkinter import *
from deaf import open_dialog
# from Hand_Gesture_Ex1 import open_dialog1
from Hand_Gesture_Ex2 import open_dialog2
from tkinter.ttk import *


root = Tk()
# This is the section of code which creates the main window
root.geometry('500x400')
root.configure(background='#2e2d2d')
root.title('AWAZ main window')

#Create style object
sto = Style()

#configure style
sto.configure('TButton', background = 'blue', foreground = 'blue', width = 20, borderwidth=1, focusthickness=3, focuscolor='none')
sto.map('TButton', background=[('active','red')])

# This is the section of code which creates the a label
Label(root, text='AWAZ', font=('arial', 25, 'normal'), background='#2e2d2d', foreground = 'white').place(x=200, y=53)

# Buttons section
myBtn1 = Button(root, text='Deaf / Dumb', width=16, command=lambda:open_dialog())
myBtn1.grid(row = 0, column = 3, pady = 100, padx = 220)
myBtn1.place(relx=0.4, rely=0.4)
myBtn2 = Button(root, text='Normal Person', width=16, command=lambda:open_dialog2())
myBtn2.grid(row = 1, column = 3, pady = 10, padx = 100)
myBtn2.place(relx=0.4, rely=0.3)

root.mainloop()
